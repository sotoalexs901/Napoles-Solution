import { motion } from "framer-motion";
import { useLang } from "../context/LangContext";

export default function Services() {
  const { t } = useLang();
  return (
    <section id="services" className="py-20 px-6 max-w-6xl mx-auto">
      <h2 className="text-3xl md:text-4xl font-orbitron text-neon mb-10">{t.services.title}</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {t.services.items.map((card, idx) => (
          <motion.div
            key={idx}
            className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-neon/40 transition shadow-lg"
            whileHover={{ y: -4 }}
          >
            <h3 className="text-xl font-semibold mb-2">{card.title}</h3>
            <p className="text-gray-400">{card.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
