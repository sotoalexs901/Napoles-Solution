import { useLang } from "../context/LangContext";
import { motion } from "framer-motion";

export default function Navbar() {
  const { t, toggle, lang } = useLang();
  const items = [
    { key: "home", href: "#home" },
    { key: "services", href: "#services" },
    { key: "portfolio", href: "#portfolio" },
    { key: "contact", href: "#contact" },
  ];
  return (
    <nav className="fixed top-0 left-0 right-0 backdrop-blur bg-black/30 z-50">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
        <a href="#home" className="flex items-center gap-3">
          <img src="/logo.png" alt="AMNS logo" className="w-10" />
          <span className="font-orbitron tracking-widest text-neon">AMNS</span>
        </a>
        <ul className="hidden md:flex items-center gap-8">
          {items.map((it) => (
            <li key={it.key}>
              <a href={it.href} className="text-sm uppercase tracking-widest hover:text-neon transition">
                {t.nav[it.key]}
              </a>
            </li>
          ))}
        </ul>
        <motion.button whileHover={{ scale: 1.05 }} onClick={toggle} className="neon-border px-3 py-1 rounded-full text-xs uppercase tracking-widest">
          {lang === "es" ? "EN" : "ES"}
        </motion.button>
      </div>
    </nav>
  );
}
