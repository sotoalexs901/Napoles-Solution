import { useLang } from "../context/LangContext";

export default function Footer() {
  const { t } = useLang();
  return (
    <footer className="py-10 text-center text-sm text-gray-400 border-t border-white/10">
      {t.footer.rights}
    </footer>
  );
}
