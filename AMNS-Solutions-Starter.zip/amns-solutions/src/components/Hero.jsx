import { motion } from "framer-motion";
import { useLang } from "../context/LangContext";

export default function Hero() {
  const { t } = useLang();
  return (
    <section id="home" className="min-h-[85vh] grid place-items-center text-center relative overflow-hidden">
      <motion.img
        src="/logo.png"
        alt="AMNS Solutions Logo"
        className="w-40 mb-6 drop-shadow-[0_0_25px_#00e0ff]"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1 }}
      />
      <div className="max-w-3xl mx-auto px-6">
        <motion.h1
          className="text-4xl md:text-6xl font-orbitron text-neon tracking-widest"
          initial={{ y: -20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {t.hero.title}
        </motion.h1>
        <motion.p
          className="mt-4 text-xl md:text-2xl text-gray-200"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 0.8 }}
        >
          {t.hero.headline}
        </motion.p>
        <motion.p
          className="mt-3 text-gray-400"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4, duration: 0.8 }}
        >
          {t.hero.sub}
        </motion.p>
        <motion.a
          href="#contact"
          className="mt-8 inline-block neon-border px-8 py-3 rounded-full text-neon font-semibold tracking-wide hover:bg-neon hover:text-dark transition-all duration-300"
          whileHover={{ scale: 1.05 }}
        >
          {t.hero.cta} →
        </motion.a>
      </div>

      <motion.div
        className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_center,_rgba(0,224,255,0.07)_0%,_transparent_70%)]"
        animate={{ backgroundPosition: ["0% 0%", "100% 100%", "0% 0%"] }}
        transition={{ duration: 14, repeat: Infinity, ease: "linear" }}
      />
    </section>
  );
}
