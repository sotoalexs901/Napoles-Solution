import { motion } from "framer-motion";
import { useLang } from "../context/LangContext";

export default function Contact() {
  const { t } = useLang();
  return (
    <section id="contact" className="py-20 px-6 max-w-3xl mx-auto">
      <h2 className="text-3xl md:text-4xl font-orbitron text-neon mb-3">{t.contact.title}</h2>
      <p className="text-gray-400 mb-8">{t.contact.subtitle}</p>
      <form className="grid gap-4">
        <input className="bg-white/5 border border-white/10 rounded-xl p-3" placeholder={t.contact.name} />
        <input type="email" className="bg-white/5 border border-white/10 rounded-xl p-3" placeholder={t.contact.email} />
        <textarea rows="5" className="bg-white/5 border border-white/10 rounded-xl p-3" placeholder={t.contact.msg}></textarea>
        <motion.button whileHover={{ scale: 1.02 }} className="neon-border px-6 py-3 rounded-full text-neon font-semibold tracking-wide hover:bg-neon hover:text-dark transition-all duration-300 w-fit">
          {t.contact.send}
        </motion.button>
      </form>
    </section>
  );
}
