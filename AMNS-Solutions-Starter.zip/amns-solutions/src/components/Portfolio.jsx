import { motion } from "framer-motion";
import { useLang } from "../context/LangContext";

export default function Portfolio() {
  const { t } = useLang();
  return (
    <section id="portfolio" className="py-20 px-6 max-w-6xl mx-auto">
      <h2 className="text-3xl md:text-4xl font-orbitron text-neon mb-6">{t.portfolio.title}</h2>
      <p className="text-gray-400 mb-6">{t.portfolio.soon}</p>
      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
        {[1,2,3,4,5,6].map((n) => (
          <motion.div key={n} className="aspect-video rounded-2xl bg-white/5 border border-white/10" whileHover={{ scale: 1.02 }} />
        ))}
      </div>
    </section>
  );
}
