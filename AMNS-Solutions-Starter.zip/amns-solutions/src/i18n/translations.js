export const translations = {
  es: {
    nav: { home: "Inicio", services: "Servicios", portfolio: "Portafolio", contact: "Contacto" },
    hero: {
      title: "AMNS Solutions",
      headline: "Diseñamos el futuro digital de tu marca.",
      sub: "Websites veloces, futuristas y con actitud.",
      cta: "Construye tu website"
    },
    services: {
      title: "Servicios",
      items: [
        { title: "Diseño Web Futurista", desc: "Interfaces oscuras, neón y micro-animaciones con enfoque en conversión." },
        { title: "Landing Pages & Funnels", desc: "Páginas listas para campañas con formularios e integraciones." },
        { title: "SEO & Performance", desc: "Sitios ultrarrápidos, optimizados para Google y móviles." }
      ]
    },
    portfolio: { title: "Portafolio", soon: "Pronto mostraremos proyectos con brillo propio." },
    contact: { title: "Contacto", subtitle: "Cuéntanos tu idea y te respondemos rápido.", name: "Nombre", email: "Email", msg: "Mensaje", send: "Enviar" },
    footer: { rights: "© AMNS Solutions. Todos los derechos reservados." },
    lang: "ES"
  },
  en: {
    nav: { home: "Home", services: "Services", portfolio: "Portfolio", contact: "Contact" },
    hero: {
      title: "AMNS Solutions",
      headline: "We design your brand’s digital future.",
      sub: "Fast, futuristic websites with attitude.",
      cta: "Build your website"
    },
    services: {
      title: "Services",
      items: [
        { title: "Futuristic Web Design", desc: "Dark UI, neon accents and micro-animations focused on conversion." },
        { title: "Landing Pages & Funnels", desc: "Campaign-ready pages with forms and integrations." },
        { title: "SEO & Performance", desc: "Ultra-fast sites, optimized for Google and mobile." }
      ]
    },
    portfolio: { title: "Portfolio", soon: "Soon we’ll showcase projects that truly shine." },
    contact: { title: "Contact", subtitle: "Tell us your idea and we’ll reply fast.", name: "Name", email: "Email", msg: "Message", send: "Send" },
    footer: { rights: "© AMNS Solutions. All rights reserved." },
    lang: "EN"
  }
}
