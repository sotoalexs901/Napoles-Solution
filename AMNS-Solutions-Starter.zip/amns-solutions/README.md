# AMNS Solutions

Website boilerplate (React + Vite + Tailwind + Framer Motion) with bilingual EN/ES toggle.

## Quick start

```bash
npm install
npm run dev
```

### Build for Netlify

- Build command: `npm run build`
- Publish directory: `dist`
